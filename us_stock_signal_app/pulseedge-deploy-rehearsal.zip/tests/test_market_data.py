from __future__ import annotations

import unittest
from unittest.mock import patch

import market_data
from app import analyze_watchlist


def base_config() -> dict:
    return {
        "provider": "demo",
        "watchlist": ["AAPL"],
        "positions": [{"symbol": "AAPL", "held": True}],
        "alpaca": {"feed": "iex", "timeframe": "1Day", "lookback_days": 260},
    }


def sample_bars() -> list[dict]:
    return [
        {"time": "2026-09-14T04:00:00Z", "open": 99, "high": 101, "low": 98, "close": 100, "volume": 1000},
        {"time": "2026-09-15T04:00:00Z", "open": 100, "high": 103, "low": 99, "close": 102, "volume": 1200},
    ]


class MarketDataCacheTests(unittest.TestCase):
    def setUp(self) -> None:
        market_data._BAR_CACHE.clear()
        market_data._VIX_CACHE.clear()
        market_data.reset_market_data_usage()

    def tearDown(self) -> None:
        market_data._BAR_CACHE.clear()
        market_data._VIX_CACHE.clear()
        market_data.reset_market_data_usage()

    def test_fetch_bars_reuses_cache_and_returns_copy(self) -> None:
        with patch("market_data.generate_demo_bars", return_value=sample_bars()) as generate:
            first = market_data.fetch_bars("AAPL", base_config())
            first[0]["close"] = 999
            second = market_data.fetch_bars("AAPL", base_config())

        self.assertEqual(generate.call_count, 1)
        self.assertEqual(second[0]["close"], 100)
        usage = market_data.market_data_usage_snapshot()
        self.assertEqual(usage["bar_cache"]["hits"], 1)
        self.assertEqual(usage["bar_cache"]["misses"], 1)
        self.assertEqual(usage["bar_cache"]["hit_rate_pct"], 50.0)
        self.assertEqual(usage["demo_generations"], 1)

    def test_cache_key_changes_when_feed_changes(self) -> None:
        config = base_config()
        other_config = base_config()
        other_config["alpaca"]["feed"] = "delayed_sip"

        with patch("market_data.generate_demo_bars", return_value=sample_bars()) as generate:
            market_data.fetch_bars("AAPL", config)
            market_data.fetch_bars("AAPL", other_config)

        self.assertEqual(generate.call_count, 2)

    def test_usage_snapshot_counts_vix_cache(self) -> None:
        config = base_config()
        config["fear"] = {"source": "demo", "lookback_days": 30}

        first = market_data.fetch_vix_history(config)
        second = market_data.fetch_vix_history(config)
        usage = market_data.market_data_usage_snapshot()

        self.assertEqual(first, second)
        self.assertEqual(usage["vix"]["cache_misses"], 1)
        self.assertEqual(usage["vix"]["cache_hits"], 1)
        self.assertEqual(usage["vix"]["hit_rate_pct"], 50.0)


class AnalyzeWatchlistTests(unittest.TestCase):
    def test_parallel_analysis_preserves_symbol_order_and_errors(self) -> None:
        config = base_config()
        config["watchlist"] = ["MSFT", "BAD", "AAPL"]
        watch_config = {**config, "positions": []}

        def fake_fetch_bars(symbol: str, _: dict) -> list[dict]:
            if symbol == "BAD":
                raise RuntimeError("boom")
            return sample_bars()

        def fake_analyze_symbol(symbol: str, _: list[dict], active_config: dict) -> dict:
            return {
                "symbol": symbol,
                "position_count": len(active_config.get("positions", [])),
                "alert_level": "대기",
                "signals": [],
            }

        with (
            patch("app.fetch_bars", side_effect=fake_fetch_bars),
            patch("app.analyze_symbol", side_effect=fake_analyze_symbol),
        ):
            results, watch_results = analyze_watchlist(config["watchlist"], config, watch_config)

        self.assertEqual([result["symbol"] for result in results], ["MSFT", "BAD", "AAPL"])
        self.assertEqual([result["symbol"] for result in watch_results], ["MSFT", "BAD", "AAPL"])
        self.assertEqual(results[1]["alert_level"], "오류")
        self.assertEqual(results[0]["position_count"], 1)
        self.assertEqual(watch_results[0]["position_count"], 0)


if __name__ == "__main__":
    unittest.main()
